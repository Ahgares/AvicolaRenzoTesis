# predictor actualizado (placeholder)
